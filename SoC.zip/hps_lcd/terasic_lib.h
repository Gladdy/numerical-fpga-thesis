#ifndef _INC_TERASIC_LIB_H_
#define _INC_TERASIC_LIB_H_

long get_tick_count(void);


#endif //_INC_TERASIC_LIB_H_